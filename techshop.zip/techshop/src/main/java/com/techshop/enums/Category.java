package com.techshop.enums;

public enum Category {
    LAPTOP, PHONE, GAMING_EQUIPMENT, SMART_DEVICES

}
