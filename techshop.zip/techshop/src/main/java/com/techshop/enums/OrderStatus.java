package com.techshop.enums;

public enum OrderStatus {
    PENDING, SHIPPED, DELIVERED, CANCELLED

}
