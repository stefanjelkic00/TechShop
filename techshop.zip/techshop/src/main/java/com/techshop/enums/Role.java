package com.techshop.enums;

public enum Role {
	ADMIN, CUSTOMER
}
