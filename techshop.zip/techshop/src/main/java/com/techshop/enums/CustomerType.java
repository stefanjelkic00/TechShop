package com.techshop.enums;

public enum CustomerType {
    REGULAR, PREMIUM, PLATINUM, VIP

}
